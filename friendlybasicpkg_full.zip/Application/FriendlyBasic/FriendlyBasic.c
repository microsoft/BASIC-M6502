//
// FriendlyBasic.c
// Enhanced Friendly BASIC for UEFI
// Features added:
// - Labels (label:) and GOTO label
// - IF <expr> THEN <single-command> (supports THEN GOTO label)
// - DIM arrays, array access A[expr]
// - Expression parser with precedence and parentheses (shunting-yard)
// - Volume selector for SAVE/OPEN
// - REPL, program buffer, SAVE/OPEN/LIST/RUN/NEW/QUIT
//
// NOTE: Prototype code for use in EDK II. Test in VM (OVMF) before using on hardware.
//

#include <Uefi.h>
#include <Library/UefiLib.h>
#include <Library/UefiBootServicesTableLib.h>
#include <Library/ShellCEntryLib.h>
#include <Library/MemoryAllocationLib.h>
#include <Library/BaseMemoryLib.h>
#include <Library/PrintLib.h>
#include <Protocol/SimpleFileSystem.h>
#include <Protocol/DevicePath.h>
#include <Guid/FileInfo.h>

#define MAX_LINE_LEN 512
#define MAX_PROGRAM_LINES 4096
#define MAX_VARS 512
#define MAX_VAR_NAME 64
#define MAX_LABELS 1024
#define MAX_ARRAYS 128
#define MAX_ARRAY_NAME 64
#define MAX_FSYS_HANDLES 32

typedef struct {
  CHAR16 Name[MAX_VAR_NAME];
  INT64  Value;
  BOOLEAN Used;
} VAR_ENTRY;

typedef struct {
  CHAR16 Name[MAX_ARRAY_NAME];
  INT64 *Data;
  UINTN Size;
  BOOLEAN Used;
} ARRAY_ENTRY;

typedef struct {
  CHAR16 Name[MAX_VAR_NAME];
  INTN LineIndex;
  BOOLEAN Used;
} LABEL_ENTRY;

static VAR_ENTRY Vars[MAX_VARS];
static ARRAY_ENTRY Arrays[MAX_ARRAYS];
static LABEL_ENTRY Labels[MAX_LABELS];
static CHAR16* ProgramLines[MAX_PROGRAM_LINES];
static UINTN ProgramLineCount = 0;
static INTN LabelCount = 0;

static EFI_HANDLE FsHandles[MAX_FSYS_HANDLES]; static UINTN FsHandleCount = 0;

static BOOLEAN FriendlyMode = TRUE;

// Alias mapping
typedef struct { CHAR16* alias; CHAR16* canonical; } ALIAS;
static ALIAS Aliases[] = {
  {L"say",   L"PRINT"}, {L"print", L"PRINT"},
  {L"ask",   L"INPUT"}, {L"input", L"INPUT"},
  {L"set",   L"LET"}, {L"let", L"LET"},
  {L"jump",  L"GOTO"}, {L"goto", L"GOTO"},
  {L"call",  L"GOSUB"}, {L"back",  L"RETURN"},
  {L"show",  L"LIST"}, {L"go",    L"RUN"}, {L"run",   L"RUN"},
  {L"reset", L"NEW"}, {L"clear", L"CLS"}, {L"open",  L"OPEN"},
  {L"save",  L"SAVE"}, {L"files", L"FILES"}, {L"#",     L"REM"},
  {L"quit",  L"QUIT"}, {L"end",   L"QUIT"}, {L"dim", L"DIM"}
};

// ---------- Utilities ----------
STATIC VOID ToUpperStr(CHAR16 *s) {
  for (; *s; s++) { if (*s >= L'a' && *s <= L'z') *s = (CHAR16)(*s - L'a' + L'A'); }
}

STATIC EFI_STATUS ReadLine(CHAR16* Buffer, UINTN BufChars) {
  EFI_INPUT_KEY Key;
  UINTN idx = 0;
  Buffer[0] = L'\0';
  while (TRUE) {
    EFI_STATUS st = gST->ConIn->ReadKeyStroke(gST->ConIn, &Key);
    if (st == EFI_NOT_READY) { gBS->Stall(1000); continue; }
    if (Key.UnicodeChar == CHAR_LINEFEED || Key.UnicodeChar == CHAR_CARRIAGE_RETURN) {
      Buffer[idx] = L'\0';
      Print(L"\n");
      return EFI_SUCCESS;
    } else if (Key.UnicodeChar == CHAR_BACKSPACE) {
      if (idx > 0) { idx--; Print(L"\x8 \x8"); }
    } else if (Key.UnicodeChar >= 0x20) {
      if (idx + 1 < BufChars) { Buffer[idx++] = Key.UnicodeChar; Buffer[idx] = L'\0'; Print(L"%c", Key.UnicodeChar); }
    }
  }
}

// ---------- Variables / Arrays ----------
STATIC VAR_ENTRY* FindVar(const CHAR16* name) {
  for (UINTN i = 0; i < MAX_VARS; ++i) { if (Vars[i].Used && StrCmp(Vars[i].Name, (CHAR16*)name) == 0) return &Vars[i]; }
  return NULL;
}
STATIC VAR_ENTRY* CreateOrGetVar(const CHAR16* name) {
  VAR_ENTRY* v = FindVar(name);
  if (v) return v;
  for (UINTN i = 0; i < MAX_VARS; ++i) {
    if (!Vars[i].Used) {
      StrnCpyS(Vars[i].Name, MAX_VAR_NAME, (CHAR16*)name, StrLen((CHAR16*)name));
      Vars[i].Value = 0; Vars[i].Used = TRUE; return &Vars[i];
    }
  }
  return NULL;
}

STATIC ARRAY_ENTRY* FindArray(const CHAR16* name) {
  for (UINTN i = 0; i < MAX_ARRAYS; ++i) if (Arrays[i].Used && StrCmp(Arrays[i].Name, (CHAR16*)name) == 0) return &Arrays[i];
  return NULL;
}
STATIC ARRAY_ENTRY* CreateArray(const CHAR16* name, UINTN size) {
  ARRAY_ENTRY* a = FindArray(name);
  if (a) {
    // reallocate if size different
    if (a->Size != size) {
      if (a->Data) FreePool(a->Data);
      a->Data = AllocatePool(size * sizeof(INT64));
      if (!a->Data) { a->Size = 0; a->Used = FALSE; return NULL; }
      a->Size = size;
    }
    return a;
  }
  for (UINTN i = 0; i < MAX_ARRAYS; ++i) {
    if (!Arrays[i].Used) {
      StrnCpyS(Arrays[i].Name, MAX_ARRAY_NAME, (CHAR16*)name, StrLen((CHAR16*)name));
      Arrays[i].Data = AllocatePool(size * sizeof(INT64));
      if (!Arrays[i].Data) { Arrays[i].Used = FALSE; return NULL; }
      Arrays[i].Size = size; Arrays[i].Used = TRUE;
      // init zeros
      for (UINTN j=0;j<size;++j) Arrays[i].Data[j]=0;
      return &Arrays[i];
    }
  }
  return NULL;
}

// ---------- Tokenizer + expression evaluator (supports arrays access NAME[expr]) ----------
typedef enum { TOK_NUM, TOK_VAR, TOK_OP, TOK_LPAR, TOK_RPAR, TOK_ARR } TOKTYPE;
typedef struct { TOKTYPE t; CHAR16 text[128]; } TOKEN;

STATIC VOID TrimLeading(CHAR16* s) { while (*s == L' ') StrCpy(s,s+1); }

// Checks if a character is identifier char
STATIC BOOLEAN IsIdentChar(CHAR16 c) {
  return ((c >= L'A' && c <= L'Z') || (c >= L'a' && c <= L'z') || (c >= L'0' && c <= L'9') || c == L'_' );
}

// Tokenize expression; supports number, var, arr[index], operators + - * /, parentheses
STATIC UINTN TokenizeExpr(const CHAR16* expr, TOKEN* outTokens, UINTN maxTokens) {
  UINTN idx = 0; UINTN i = 0; UINTN len = StrLen(expr);
  while (i < len && idx < maxTokens) {
    CHAR16 c = expr[i];
    if (c == L' ' || c == L'\t') { i++; continue; }
    if (c == L'+' || c == L'-' || c == L'*' || c == L'/') {
      outTokens[idx].t = TOK_OP; outTokens[idx].text[0] = c; outTokens[idx].text[1] = 0; idx++; i++; continue;
    }
    if (c == L'(') { outTokens[idx].t = TOK_LPAR; outTokens[idx].text[0] = L'('; outTokens[idx].text[1]=0; idx++; i++; continue; }
    if (c == L')') { outTokens[idx].t = TOK_RPAR; outTokens[idx].text[0] = L')'; outTokens[idx].text[1]=0; idx++; i++; continue; }
    // array or var or number
    if ((c >= L'0' && c <= L'9') || (c == L'-' && i+1 < len && expr[i+1] >= L'0' && expr[i+1] <= L'9')) {
      // number (support negative leading)
      UINTN p=0; CHAR16 buf[128];
      if (c == L'-') { buf[p++]=c; i++; }
      while (i < len && expr[i] >= L'0' && expr[i] <= L'9' && p+1<128) buf[p++]=expr[i++];
      buf[p]=0; outTokens[idx].t = TOK_NUM; StrnCpyS(outTokens[idx].text,128,buf,127); idx++; continue;
    }
    if (IsIdentChar(c)) {
      UINTN p=0; CHAR16 name[128];
      while (i < len && IsIdentChar(expr[i]) && p+1<128) name[p++]=expr[i++];
      name[p]=0;
      // check for array open '['
      if (i < len && expr[i] == L'[') {
        // find matching ]
        i++; UINTN start = i; INTN depth = 1;
        while (i < len && depth > 0) {
          if (expr[i] == L'[') depth++;
          else if (expr[i] == L']') depth--;
          i++;
        }
        UINTN end = i-1; // position of ]
        UINTN innerLen = end - start;
        CHAR16 inner[256]; if (innerLen >= 255) innerLen = 255;
        for (UINTN k=0;k<innerLen;k++) inner[k]=expr[start+k]; inner[innerLen]=0;
        // store as special token: NAME[innerexpr]
        outTokens[idx].t = TOK_ARR;
        StrnCpyS(outTokens[idx].text,128,name,127);
        StrnCatS(outTokens[idx].text,128,L"["); StrnCatS(outTokens[idx].text,128,inner); StrnCatS(outTokens[idx].text,128,L"]");
        idx++; continue;
      } else {
        outTokens[idx].t = TOK_VAR; StrnCpyS(outTokens[idx].text,128,name,127); idx++; continue;
      }
    }
    // unknown, skip
    i++;
  }
  return idx;
}

STATIC INTN OpPrec(CHAR16 op) { if (op == L'+' || op == L'-') return 1; if (op == L'*' || op == L'/') return 2; return 0; }

STATIC UINTN ShuntingYard(TOKEN* tokens, UINTN nt, TOKEN* outputTokens, UINTN maxOut) {
  TOKEN opstack[256]; INTN opTop = -1; UINTN outIdx = 0;
  for (UINTN i = 0; i < nt; ++i) {
    TOKEN tk = tokens[i];
    if (tk.t == TOK_NUM || tk.t == TOK_VAR || tk.t == TOK_ARR) {
      if (outIdx < maxOut) outputTokens[outIdx++] = tk; else return 0;
    } else if (tk.t == TOK_OP) {
      CHAR16 op = tk.text[0];
      while (opTop >= 0 && opstack[opTop].t == TOK_OP && OpPrec(opstack[opTop].text[0]) >= OpPrec(op)) {
        if (outIdx < maxOut) outputTokens[outIdx++] = opstack[opTop--]; else return 0;
      }
      opstack[++opTop] = tk;
    } else if (tk.t == TOK_LPAR) {
      opstack[++opTop] = tk;
    } else if (tk.t == TOK_RPAR) {
      while (opTop >= 0 && opstack[opTop].t != TOK_LPAR) {
        if (outIdx < maxOut) outputTokens[outIdx++] = opstack[opTop--]; else return 0;
      }
      if (opTop >= 0 && opstack[opTop].t == TOK_LPAR) opTop--;
    }
  }
  while (opTop >= 0) { if (outIdx < maxOut) outputTokens[outIdx++] = opstack[opTop--]; else return 0; }
  return outIdx;
}

STATIC BOOLEAN ParseInt64(const CHAR16* s, INT64* out) {
  if (s == NULL || *s == L'\0') return FALSE;
  BOOLEAN neg = FALSE; if (*s == L'-') { neg = TRUE; s++; }
  INT64 v = 0; BOOLEAN any = FALSE;
  while (*s) { if (*s >= L'0' && *s <= L'9') { v = v * 10 + (*s - L'0'); any = TRUE; } else return FALSE; s++; }
  *out = neg ? -v : v; return any;
}

// Evaluate RPN with array resolve
STATIC BOOLEAN EvalRPN(TOKEN* rpn, UINTN rn, INT64* out) {
  INT64 stackv[512]; INTN top=-1;
  for (UINTN i=0;i<rn;++i) {
    TOKEN t = rpn[i];
    if (t.t == TOK_NUM) { INT64 v; if (!ParseInt64(t.text,&v)) return FALSE; stackv[++top]=v; }
    else if (t.t == TOK_VAR) { VAR_ENTRY* ve = FindVar(t.text); INT64 v = (ve?ve->Value:0); stackv[++top]=v; }
    else if (t.t == TOK_ARR) {
      // format NAME[innerexpr], split name and inner
      CHAR16 *p = StrStr(t.text, L"[");
      if (!p) return FALSE;
      CHAR16 name[128]; UINTN nl = (UINTN)(p - t.text); if (nl >= 127) nl = 127;
      for (UINTN k=0;k<nl;k++) name[k]=t.text[k]; name[nl]=0;
      // inner expr
      CHAR16 inner[256]; UINTN il = StrLen(t.text) - nl - 2; // skip ] too
      if (il >= 255) il = 255;
      for (UINTN k=0;k<il;k++) inner[k] = t.text[nl+1+k]; inner[il]=0;
      // evaluate inner expr recursively
      TOKEN itoks[128]; UINTN in = TokenizeExpr(inner, itoks, 128); TOKEN irpn[128]; UINTN irn = ShuntingYard(itoks, in, irpn, 128);
      INT64 idxval = 0; if (!EvalRPN(irpn, irn, &idxval)) return FALSE;
      if (idxval < 0) return FALSE;
      ARRAY_ENTRY* ae = FindArray(name);
      if (!ae) return FALSE;
      if ((UINTN)idxval >= ae->Size) return FALSE;
      stackv[++top] = ae->Data[idxval];
    }
    else if (t.t == TOK_OP) {
      if (top < 1) return FALSE;
      INT64 b = stackv[top--]; INT64 a = stackv[top--]; INT64 r=0; CHAR16 op = t.text[0];
      switch (op) { case L'+': r=a+b; break; case L'-': r=a-b; break; case L'*': r=a*b; break; case L'/': if (b==0) return FALSE; r=a/b; break; default: return FALSE; }
      stackv[++top]=r;
    } else return FALSE;
  }
  if (top != 0) return FALSE; *out = stackv[top]; return TRUE;
}

STATIC BOOLEAN EvalExprFull(CHAR16* expr, INT64* result) {
  TOKEN tokens[256]; UINTN nt = TokenizeExpr(expr, tokens, 256);
  if (nt == 0) return FALSE;
  TOKEN rpn[256]; UINTN rn = ShuntingYard(tokens, nt, rpn, 256);
  if (rn == 0) return FALSE;
  return EvalRPN(rpn, rn, result);
}

// ---------- Preparser and program buffer ----------
STATIC VOID PreParseLine(CHAR16* Line) {
  TrimLeading(Line);
  if (*Line == L'\0') return;
  CHAR16 tmp[MAX_LINE_LEN]; StrnCpyS(tmp, MAX_LINE_LEN, Line, MAX_LINE_LEN-1);
  CHAR16* saveptr; CHAR16* first = StrTokenW(tmp, L" ", &saveptr);
  if (!first) return;
  for (UINTN i=0;i<sizeof(Aliases)/sizeof(ALIAS);++i) {
    CHAR16 aliasup[128]; StrnCpyS(aliasup,128,Aliases[i].alias,127); ToUpperStr(aliasup);
    CHAR16 firstup[128]; StrnCpyS(firstup,128,first,127); ToUpperStr(firstup);
    if (StrCmp(aliasup, firstup) == 0) {
      CHAR16 rest[MAX_LINE_LEN]; rest[0]=0;
      CHAR16* p = Line; while (*p && *p != L' ') p++; if (*p) StrnCpyS(rest, MAX_LINE_LEN, p, MAX_LINE_LEN-1);
      CHAR16 newl[MAX_LINE_LEN]; newl[0]=0; StrnCatS(newl, MAX_LINE_LEN, Aliases[i].canonical); StrnCatS(newl, MAX_LINE_LEN, rest);
      StrnCpyS(Line, MAX_LINE_LEN, newl, MAX_LINE_LEN-1); break;
    }
  }
}

STATIC VOID AddProgramLine(CHAR16* line) {
  if (ProgramLineCount >= MAX_PROGRAM_LINES) return;
  UINTN len = StrLen(line) + 1;
  CHAR16* copy = AllocatePool(len * sizeof(CHAR16));
  if (!copy) return;
  StrnCpyS(copy, len, line, len-1);
  ProgramLines[ProgramLineCount++] = copy;
}

STATIC VOID ClearProgram() {
  for (UINTN i = 0; i < ProgramLineCount; ++i) if (ProgramLines[i]) FreePool(ProgramLines[i]);
  ProgramLineCount = 0;
}

// ---------- Label handling ----------
STATIC VOID RegisterLabels() {
  for (INTN i=0;i<MAX_LABELS;i++) Labels[i].Used = FALSE;
  LabelCount = 0;
  for (UINTN idx=0; idx<ProgramLineCount; ++idx) {
    CHAR16 tmp[MAX_LINE_LEN]; StrnCpyS(tmp, MAX_LINE_LEN, ProgramLines[idx], MAX_LINE_LEN-1);
    TrimLeading(tmp);
    CHAR16* colon = StrChr(tmp, L':');
    if (colon) {
      UINTN len = (UINTN)(colon - tmp);
      if (len > 0 && LabelCount < MAX_LABELS) {
        StrnCpyS(Labels[LabelCount].Name, MAX_VAR_NAME, tmp, len);
        Labels[LabelCount].LineIndex = (INTN)idx;
        Labels[LabelCount].Used = TRUE;
        LabelCount++;
      }
    }
  }
}

STATIC INTN FindLabelIndex(const CHAR16* name) {
  for (INTN i=0;i<LabelCount;i++) if (Labels[i].Used && StrCmp(Labels[i].Name, (CHAR16*)name)==0) return Labels[i].LineIndex;
  return -1;
}

// ---------- File I/O (volume selector) ----------
STATIC VOID RefreshFsHandles() {
  if (FsHandleCount) { for (UINTN i=0;i<FsHandleCount;++i) FsHandles[i]=NULL; FsHandleCount=0; }
  EFI_STATUS st = gBS->LocateHandleBuffer(ByProtocol, &gEfiSimpleFileSystemProtocolGuid, NULL, &FsHandleCount, &FsHandles);
  if (EFI_ERROR(st) || FsHandleCount==0) { FsHandleCount = 0; return; }
  if (FsHandleCount > MAX_FSYS_HANDLES) FsHandleCount = MAX_FSYS_HANDLES;
}

STATIC INTN ChooseVolumePrompt() {
  RefreshFsHandles(); if (FsHandleCount==0) { Print(L"No file systems available.\n"); return -1; }
  Print(L"Select volume (index):\n");
  for (UINTN i=0;i<FsHandleCount;++i) Print(L"  [%u]\n", i);
  Print(L"> ");
  CHAR16 buf[32]; ReadLine(buf, 32);
  INT64 idx; if (!ParseInt64(buf, &idx)) return -1;
  if (idx < 0 || (UINTN)idx >= FsHandleCount) return -1;
  return (INTN)idx;
}

STATIC EFI_STATUS SaveToVolume(UINTN volIndex, CHAR16* FileName) {
  if (volIndex >= FsHandleCount) return EFI_NOT_FOUND;
  EFI_SIMPLE_FILE_SYSTEM_PROTOCOL* Sfs; EFI_STATUS st = gBS->HandleProtocol(FsHandles[volIndex], &gEfiSimpleFileSystemProtocolGuid, (VOID**)&Sfs);
  if (EFI_ERROR(st)) return st;
  EFI_FILE_PROTOCOL* Root; st = Sfs->OpenVolume(Sfs, &Root); if (EFI_ERROR(st)) return st;
  CHAR16 fname[256]; StrnCpyS(fname,256,FileName,255); if (!StrStr(fname,L".bas")) StrnCatS(fname,256,L".bas");
  EFI_FILE_PROTOCOL* File; st = Root->Open(Root, &File, fname, EFI_FILE_MODE_READ|EFI_FILE_MODE_WRITE|EFI_FILE_MODE_CREATE, 0); if (EFI_ERROR(st)) { Root->Close(Root); return st; }
  for (UINTN i=0;i<ProgramLineCount;++i) {
    CHAR16* line = ProgramLines[i]; if (!line) continue;
    UINTN bytes = StrLen(line) * sizeof(CHAR16);
    st = File->Write(File, &bytes, line); if (EFI_ERROR(st)) { File->Close(File); Root->Close(Root); return st; }
    CHAR16 crlf[2] = {L'\r', L'\n'}; UINTN crbytes = 2*sizeof(CHAR16); st = File->Write(File, &crbytes, crlf); if (EFI_ERROR(st)) { File->Close(File); Root->Close(Root); return st; }
  }
  File->Close(File); Root->Close(Root); return EFI_SUCCESS;
}

STATIC EFI_STATUS OpenFromVolume(UINTN volIndex, CHAR16* FileName) {
  if (volIndex >= FsHandleCount) return EFI_NOT_FOUND;
  EFI_SIMPLE_FILE_SYSTEM_PROTOCOL* Sfs; EFI_STATUS st = gBS->HandleProtocol(FsHandles[volIndex], &gEfiSimpleFileSystemProtocolGuid, (VOID**)&Sfs);
  if (EFI_ERROR(st)) return st;
  EFI_FILE_PROTOCOL* Root; st = Sfs->OpenVolume(Sfs, &Root); if (EFI_ERROR(st)) return st;
  CHAR16 fname[256]; StrnCpyS(fname,256,FileName,255); if (!StrStr(fname,L".bas")) StrnCatS(fname,256,L".bas");
  EFI_FILE_PROTOCOL* File; st = Root->Open(Root, &File, fname, EFI_FILE_MODE_READ, 0); if (EFI_ERROR(st)) { Root->Close(Root); return st; }
  UINTN InfoSize = 0; st = File->GetInfo(File, &gEfiFileInfoGuid, &InfoSize, NULL);
  if (st == EFI_BUFFER_TOO_SMALL) {
    EFI_FILE_INFO* Info = AllocatePool(InfoSize); if (!Info) { File->Close(File); Root->Close(Root); return EFI_OUT_OF_RESOURCES; }
    st = File->GetInfo(File, &gEfiFileInfoGuid, &InfoSize, Info); if (EFI_ERROR(st)) { FreePool(Info); File->Close(File); Root->Close(Root); return st; }
    UINTN FileSize = Info->FileSize; FreePool(Info);
    CHAR16* Buf = AllocatePool(FileSize + sizeof(CHAR16)); if (!Buf) { File->Close(File); Root->Close(Root); return EFI_OUT_OF_RESOURCES; }
    UINTN ReadSize = FileSize; st = File->Read(File, &ReadSize, Buf); if (EFI_ERROR(st)) { FreePool(Buf); File->Close(File); Root->Close(Root); return st; }
    ClearProgram();
    CHAR16* p = Buf; CHAR16 linebuf[MAX_LINE_LEN]; UINTN pos = 0;
    while (*p) {
      if (*p == L'\r' || *p == L'\n') { if (pos>0) { linebuf[pos]=0; AddProgramLine(linebuf); pos=0; } p++; continue; }
      if (pos+1<MAX_LINE_LEN) linebuf[pos++] = *p; p++;
    }
    if (pos>0) { linebuf[pos]=0; AddProgramLine(linebuf); }
    FreePool(Buf);
  }
  File->Close(File); Root->Close(Root); return EFI_SUCCESS;
}

STATIC VOID ListFilesOnVolume(UINTN volIndex) {
  if (volIndex >= FsHandleCount) { Print(L"Invalid volume\n"); return; }
  EFI_SIMPLE_FILE_SYSTEM_PROTOCOL* Sfs; EFI_STATUS st = gBS->HandleProtocol(FsHandles[volIndex], &gEfiSimpleFileSystemProtocolGuid, (VOID**)&Sfs);
  if (EFI_ERROR(st)) { Print(L"Cannot open volume\n"); return; }
  EFI_FILE_PROTOCOL* Root; st = Sfs->OpenVolume(Sfs, &Root); if (EFI_ERROR(st)) { Print(L"Open volume failed\n"); return; }
  EFI_FILE_PROTOCOL* Dir; st = Root->Open(Root, &Dir, L".", EFI_FILE_MODE_READ, 0); if (EFI_ERROR(st)) { Root->Close(Root); return; }
  UINTN BufSize = 0x1000; VOID* Buf = AllocatePool(BufSize);
  while (TRUE) {
    UINTN ReadSize = BufSize; st = Dir->Read(Dir, &ReadSize, Buf); if (EFI_ERROR(st) || ReadSize == 0) break;
    UINT8* pos = Buf;
    while ((UINTN)pos < (UINTN)Buf + ReadSize) {
      EFI_FILE_INFO* Info = (EFI_FILE_INFO*)pos; CHAR16* name = (CHAR16*)((UINT8*)Info + Info->FileNameOffset);
      Print(L"  %s\n", name);
      pos += ReadSize; // break after one read iteration in prototypes
    }
  }
  FreePool(Buf); Dir->Close(Dir); Root->Close(Root);
}

// ---------- Single-line command executor (used by IF and program execution) ----------
STATIC INTN ExecuteSingleCommand(CHAR16* line, INTN* pCurrentLine); // forward

// ---------- Program execution ----------
STATIC VOID RegisterEverything() {
  RegisterLabels();
}

STATIC VOID ExecuteProgram() {
  RegisterLabels();
  for (INTN i=0; i < (INTN)ProgramLineCount; ++i) {
    CHAR16* orig = ProgramLines[i];
    if (!orig) continue;
    CHAR16 line[MAX_LINE_LEN]; StrnCpyS(line, MAX_LINE_LEN, orig, MAX_LINE_LEN-1);
    TrimLeading(line);
    // strip label if any
    CHAR16* colon = StrChr(line, L':');
    if (colon) {
      CHAR16* rest = colon + 1;
      while (*rest == L' ') rest++;
      if (*rest == 0) continue;
      StrnCpyS(line, MAX_LINE_LEN, rest, MAX_LINE_LEN-1);
    }
    // parse and execute
    INTN rc = ExecuteSingleCommand(line, &i);
    if (rc < 0) return; // quit requested
    // ExecuteSingleCommand can modify i for GOTO
  }
}

// ---------- Command implementations ----------
STATIC INTN ExecuteSingleCommand(CHAR16* line, INTN* pCurrentLine) {
  CHAR16 buf[MAX_LINE_LEN]; StrnCpyS(buf, MAX_LINE_LEN, line, MAX_LINE_LEN-1);
  PreParseLine(buf);
  CHAR16* saveptr; CHAR16* cmd = StrTokenW(buf, L" ", &saveptr);
  if (!cmd) return 0;
  CHAR16 cmdup[64]; StrnCpyS(cmdup,64,cmd,63); ToUpperStr(cmdup);
  if (StrCmp(cmdup, L"PRINT") == 0) {
    CHAR16* rest = saveptr; if (!rest) return 0;
    INT64 v; if (EvalExprFull(rest, &v)) Print(L"%ld\n", v); else Print(L"%s\n", rest);
  } else if (StrCmp(cmdup, L"INPUT") == 0) {
    CHAR16* var = StrTokenW(NULL, L" ", &saveptr); if (!var) return 0;
    Print(L"? %s: ", var);
    CHAR16 in[MAX_LINE_LEN]; ReadLine(in, MAX_LINE_LEN); INT64 vv=0; if (!ParseInt64(in,&vv)) vv=0;
    VAR_ENTRY* ve = CreateOrGetVar(var); if (ve) ve->Value = vv;
  } else if (StrCmp(cmdup, L"LET") == 0) {
    CHAR16* var = StrTokenW(NULL, L" ", &saveptr); if (!var) return 0;
    CHAR16* eq = StrTokenW(NULL, L" ", &saveptr); // =
    CHAR16 expr[MAX_LINE_LEN]; expr[0]=0; CHAR16* t = StrTokenW(NULL, L"", &saveptr); if (t) StrnCpyS(expr,MAX_LINE_LEN,t,MAX_LINE_LEN-1);
    // support array assignment: NAME[expr] = value
    if (StrStr(var, L"[")) {
      // parse name and index
      CHAR16 *p = StrStr(var, L"[");
      CHAR16 name[128]; UINTN nl = (UINTN)(p - var); if (nl>=127) nl=127;
      for (UINTN k=0;k<nl;k++) name[k]=var[k]; name[nl]=0;
      CHAR16 inner[256]; UINTN il = StrLen(var) - nl - 2; if (il>=255) il=255;
      for (UINTN k=0;k<il;k++) inner[k]=var[nl+1+k]; inner[il]=0;
      INT64 idxv=0; if (!EvalExprFull(inner,&idxv)) { Print(L"Index error\n"); return 0; }
      ARRAY_ENTRY* ae = FindArray(name); if (!ae) { Print(L"Array not found\n"); return 0; }
      if ((UINTN)idxv >= ae->Size) { Print(L"Index out of bounds\n"); return 0; }
      INT64 rval=0; if (!EvalExprFull(expr,&rval)) { Print(L"Expression error\n"); return 0; }
      ae->Data[idxv] = rval;
    } else {
      INT64 r=0; if (EvalExprFull(expr,&r)) { VAR_ENTRY* ve = CreateOrGetVar(var); if (ve) ve->Value = r; } else Print(L"Expression error\n");
    }
  } else if (StrCmp(cmdup, L"DIM") == 0) {
    CHAR16* name = StrTokenW(NULL, L" ", &saveptr); CHAR16* sizeTok = StrTokenW(NULL, L" ", &saveptr);
    if (!name || !sizeTok) { Print(L"Usage: DIM name size\n"); return 0; }
    INT64 s=0; if (!ParseInt64(sizeTok,&s) || s <= 0) { Print(L"Invalid size\n"); return 0; }
    if (!CreateArray(name, (UINTN)s)) { Print(L"Array creation failed\n"); return 0; }
    Print(L"Array %s[%ld] created\n", name, s);
  } else if (StrCmp(cmdup, L"GOTO") == 0) {
    CHAR16* lbl = StrTokenW(NULL, L" ", &saveptr); if (!lbl) return 0;
    INTN target = FindLabelIndex(lbl);
    if (target >= 0) { *pCurrentLine = target - 1; } else { Print(L"Label not found\n"); }
  } else if (StrCmp(cmdup, L"IF") == 0) {
    // find THEN (case-insensitive)
    CHAR16* thenpos = NULL;
    // rebuild original case-insensitive find
    CHAR16 upper[MAX_LINE_LEN]; StrnCpyS(upper, MAX_LINE_LEN, buf, MAX_LINE_LEN-1); ToUpperStr(upper);
    thenpos = StrStr(upper, L" THEN ");
    if (!thenpos) { Print(L"IF syntax: IF <cond> THEN <command>\n"); return 0; }
    UINTN condlen = (UINTN)(thenpos - upper);
    CHAR16 condbuf[MAX_LINE_LEN]; StrnCpyS(condbuf, MAX_LINE_LEN, saveptr, condlen);
    // remainder after THEN in original buf (not upper)
    CHAR16* thenpart = StrStr(buf, L" THEN ");
    if (!thenpart) thenpart = StrStr(buf, L" then ");
    if (!thenpart) { Print(L"IF parse error\n"); return 0; }
    thenpart += StrLen(L" THEN ");
    INT64 condv=0;
    if (EvalExprFull(condbuf, &condv) && condv != 0) {
      // execute single command in thenpart
      ExecuteSingleCommand(thenpart, pCurrentLine);
    }
  } else if (StrCmp(cmdup, L"SAVE") == 0) {
    CHAR16* name = StrTokenW(NULL, L" ", &saveptr); if (!name) { Print(L"Usage: SAVE name\n"); return 0; }
    INTN vol = ChooseVolumePrompt(); if (vol < 0) { Print(L"No volume selected\n"); return 0; }
    EFI_STATUS st = SaveToVolume((UINTN)vol, name); if (EFI_ERROR(st)) Print(L"SAVE failed: %r\n", st); else Print(L"SAVED\n");
  } else if (StrCmp(cmdup, L"OPEN") == 0) {
    CHAR16* name = StrTokenW(NULL, L" ", &saveptr); if (!name) { Print(L"Usage: OPEN name\n"); return 0; }
    INTN vol = ChooseVolumePrompt(); if (vol < 0) { Print(L"No volume selected\n"); return 0; }
    EFI_STATUS st = OpenFromVolume((UINTN)vol, name); if (EFI_ERROR(st)) Print(L"OPEN failed: %r\n", st); else Print(L"LOADED\n");
  } else if (StrCmp(cmdup, L"FILES") == 0) {
    ListVolumes(); INTN vol = ChooseVolumePrompt(); if (vol >= 0) ListFilesOnVolume((UINTN)vol);
  } else if (StrCmp(cmdup, L"LIST") == 0) {
    for (UINTN i=0;i<ProgramLineCount;++i) Print(L"%u: %s\n", i+1, ProgramLines[i]);
  } else if (StrCmp(cmdup, L"NEW") == 0) {
    ClearProgram(); Print(L"Program cleared.\n");
  } else if (StrCmp(cmdup, L"RUN") == 0) {
    ExecuteProgram();
  } else if (StrCmp(cmdup, L"QUIT") == 0) {
    ClearProgram(); return -1; // signal quit
  } else {
    // unknown command
    Print(L"Unknown command: %s\n", cmd);
  }
  return 0;
}

// ---------- REPL ----------
EFI_STATUS EFIAPI UefiMain(IN EFI_HANDLE ImageHandle, IN EFI_SYSTEM_TABLE* SystemTable) {
  InitializeLib(ImageHandle, SystemTable);
  Print(L"Friendly BASIC (full) for UEFI\nType QUIT to exit. Use RUN to run buffer, DIM to create arrays.\n\n");
  CHAR16 line[MAX_LINE_LEN];
  RefreshFsHandles();
  while (TRUE) {
    Print(L"> ");
    ReadLine(line, MAX_LINE_LEN);
    if (StrLen(line) == 0) continue;
    // process line: if a top-level command, execute or add to buffer
    CHAR16 buf[MAX_LINE_LEN]; StrnCpyS(buf, MAX_LINE_LEN, line, MAX_LINE_LEN-1);
    PreParseLine(buf);
    CHAR16* saveptr; CHAR16* cmd = StrTokenW(buf, L" ", &saveptr);
    if (!cmd) continue;
    CHAR16 cmdup[64]; StrnCpyS(cmdup,64,cmd,63); ToUpperStr(cmdup);
    if (StrCmp(cmdup, L"RUN") == 0) { ExecuteProgram(); }
    else if (StrCmp(cmdup, L"LIST") == 0) { for (UINTN i=0;i<ProgramLineCount;++i) Print(L"%u: %s\n", i+1, ProgramLines[i]); }
    else if (StrCmp(cmdup, L"NEW") == 0) { ClearProgram(); Print(L"Program cleared.\n"); }
    else if (StrCmp(cmdup, L"SAVE") == 0) { CHAR16* name = StrTokenW(NULL,L" ",&saveptr); if (!name) { Print(L"Usage: SAVE name\n"); continue; } INTN vol = ChooseVolumePrompt(); if (vol<0) { Print(L"No volume selected\n"); continue; } EFI_STATUS st = SaveToVolume((UINTN)vol, name); if (EFI_ERROR(st)) Print(L"SAVE failed: %r\n", st); else Print(L"SAVED\n"); }
    else if (StrCmp(cmdup, L"OPEN") == 0) { CHAR16* name = StrTokenW(NULL,L" ",&saveptr); if (!name) { Print(L"Usage: OPEN name\n"); continue; } INTN vol = ChooseVolumePrompt(); if (vol<0) { Print(L"No volume selected\n"); continue; } EFI_STATUS st = OpenFromVolume((UINTN)vol, name); if (EFI_ERROR(st)) Print(L"OPEN failed: %r\n", st); else Print(L"LOADED\n"); }
    else if (StrCmp(cmdup, L"FILES") == 0) { ListVolumes(); INTN vol = ChooseVolumePrompt(); if (vol>=0) ListFilesOnVolume((UINTN)vol); }
    else if (StrCmp(cmdup, L"QUIT") == 0) { ClearProgram(); return EFI_SUCCESS; }
    else if (StrCmp(cmdup, L"PRINT")==0 || StrCmp(cmdup,L"INPUT")==0 || StrCmp(cmdup,L"LET")==0 || StrCmp(cmdup,L"DIM")==0 || StrCmp(cmdup,L"GOTO")==0 || StrCmp(cmdup,L"IF")==0) {
      // execute single-line command directly
      INTN res = ExecuteSingleCommand(line, NULL);
      if (res < 0) { ClearProgram(); return EFI_SUCCESS; }
    } else {
      // append to program buffer
      AddProgramLine(line);
      Print(L"Added to program buffer.\n");
    }
  }
  return EFI_SUCCESS;
}
