# FriendlyBasicPkg (full) for EDK II

This package provides an enhanced Friendly BASIC interpreter as a UEFI application with labels, IF, arrays, and volume selection.

Build instructions are the same as described previously. Test in VM (OVMF) before using on real hardware.
